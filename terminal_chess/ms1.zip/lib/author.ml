let hours_worked = 20
